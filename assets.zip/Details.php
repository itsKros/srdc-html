 <?php include('header.php'); ?>

 

    <!-- Details Hero Section STARTS-->

  <section class="hero-section" id="DetailsHeroSection">
    
    <div class="container d-flex">

    <div class="row col-md-8 ">
        <div class="title-section ">
                <h1>Service Name</h1>
                
                <p>At Sydney Road Dental Care, we emphasise preventive dental care and regular check-ups every six months, including dental x-rays to catch early signs of tooth decay.</p>
                <a href="#" class="btn btn-light contact-btn">Contact Us</a>
                </div>

            </div>

            <div class="details-image col-md-4" style="background-image: url('assets/imgs/Service-Details/Service-details.webp');"></div>
        </div>
    

        
      
        

    
  </section>

    <!-- Hero Section ENDS-->


   <!-- SECOND SECTION - EXPLANATION POINT START -->
   <section class="explanationSection" id="DetailsExplanationSection">

    <div class="container">

        <div class="row title-section">
            <h1>Explanation Point</h1>
            <p>Made from metals, porcelain, resin and ceramics, technological advancements
            allow dental crowns to appear like any other healthy, natural teeth.</p>
        </div>

        <div class="content-section">
            <p>Dental crowns are placed on the existing decayed, broken, or discoloured tooth or used in a dental bridge as a replacement for missing teeth.</p>
                
        <p>They help restore the original tooth’s health, function, and appearance, making them stronger and longer-lasting when fillings don’t resolve the issue.</p>
        </div>


        <div class="second-explain">
        <div class="detail-image d-flex" style="background-image: url('assets/imgs/Service-Details/details_2.webp');">
            <!-- <img src='assets/imgs/Service-Details/details_2.webp' alt=""> -->
            <!-- <p class="image-caption SF-16-black">Caption For Image</p> -->
        </div>
        <p class="image-caption SF-16-black">Caption For Image</p>
        </div>



        <div class="content-section below">
            <p>
              If you have a damaged tooth and haven’t heard of the professional dental crowns in Sydney, then it’s your lucky day! Here at   <a href="https://sydneyroaddentalcare.com.au/" class="black">Sydney Road Dental Care</a>, we have said goodbye to old dental crowns methods, and have instead welcomed the joys of what modern technology has to offer.</p>

<p>Previously, patients were required to visit the clinic at least two times before their new crown was fitted and were forced to wear an uncomfortable temporary crown in the meantime. This is now a thing of the past, and we can complete the work in a single visit.</p>

<p>Sydney Road Dental Care are dental crown experts, and not every dentist will hold that title! In fact, many other dental practices in Sydney have not yet invested in this technology, so of course you know where you’ll be heading next time you need our clinic of dental crown in Sydney!
            </p>
        </div>
    </div>

  </section>
   <!-- SECOND SECTION - EXPLANATION POINT END -->


   <!--MOBILE RESPONSIVE SECOND SECTION STARTS-->
   <section class="mobileExplanationSection d-block d-md-none" id="mobileDetailsExplanationSection">

    <div class="container">

        <div class="row title-section">
            <h1>Explanation Point</h1>
            <p>Made from metals, porcelain, resin and ceramics, technological advancements
            allow dental crowns to appear like any other healthy, natural teeth.</p>
        </div>

        <div class="content-section">
            <p>Dental crowns are placed on the existing decayed, broken, or discoloured tooth or used in a dental bridge as a replacement for missing teeth.</p>
                
        <p>They help restore the original tooth’s health, function, and appearance, making them stronger and longer-lasting when fillings don’t resolve the issue.</p>
        </div>


        <div class="second-explain">
        <div class="detail-image d-flex" style="background-image: url('assets/imgs/Service-Details/details_2.webp');">
            <!-- <img src='assets/imgs/Service-Details/details_2.webp' alt=""> -->
            <!-- <p class="image-caption SF-16-black">Caption For Image</p> -->
        </div>
        <p class="image-caption SF-16-black">Caption For Image</p>
        </div>



        <div class="content-section below">
            <p>
              If you have a damaged tooth and haven’t heard of the professional dental crowns in Sydney, then it’s your lucky day! Here at   <a href="https://sydneyroaddentalcare.com.au/" class="black">Sydney Road Dental Care</a>, we have said goodbye to old dental crowns methods, and have instead welcomed the joys of what modern technology has to offer.</p>

<p>Previously, patients were required to visit the clinic at least two times before their new crown was fitted and were forced to wear an uncomfortable temporary crown in the meantime. This is now a thing of the past, and we can complete the work in a single visit.</p>

<p>Sydney Road Dental Care are dental crown experts, and not every dentist will hold that title! In fact, many other dental practices in Sydney have not yet invested in this technology, so of course you know where you’ll be heading next time you need our clinic of dental crown in Sydney!
            </p>
        </div>
    </div>

  </section>

   <!--MOBILE RESPONSIVE SECOND SECTION ENDS-->



 <!-- THIRD SECTION - EXPLANATION POINT PART II START-->

 <section class="accordianExplanation" id="DetailsAccordianExplanation">
    <div class="container">

      <div class="row title-section d-flex">

      <!--LEFT IMAGE CONTENT-->
      <div class="row image-content-block d-flex">

        
        <div class="image-block">
          
          <h1>Explanation Point</h1>
         
          <div class="third-explain">
          <div class="d-flex align-items-center flex-column" style="background-image: url('assets/imgs/Service-Details/details_2.webp');">
          <!-- <img src='assets/imgs/Service-Details/details_2.webp' alt=""> -->
          </div>
          <p class="SF-16-black">Caption For Image</p>
          </div>
        </div>

        <!--RIGHT CONTENT CONTAINER-->
        <div class="content-block">

          
          <h3>Made from metals, porcelain, resin and ceramics, technological advancements allow dental crowns to appear like any other healthy, natural teeth.</h3>
        
        
          <p class="SF-16-black pb-3">If you have a damaged tooth and haven’t heard of the professional dental crowns in Sydney, then it’s your lucky day! Here at Sydney Road Dental Care, we have said goodbye to old dental crowns methods, and have instead welcomed the joys of what modern technology has to offer.</p>

          <p class="SF-16-black pb-3">Previously, patients were required to visit the clinic at least two times before their new crown was fitted and were forced to wear an uncomfortable temporary crown in the meantime. This is now a thing of the past, and we can complete the work in a single visit.</p>

          <p class="SF-16-black">Sydney Road Dental Care are dental crown experts, and not every dentist will hold that title! In fact, many other dental practices in Sydney have not yet invested in this technology, so of course you know where you’ll be heading next time you need our clinic of dental crown in Sydney!</p>

<!-- FAQ Section -->
  <section class="faq-section py-5" id="homeFaqSection">
    <div class="container">

      <div class="accordion accordion-flush" id="accordionFlushExample">
                
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-1" aria-expanded="false" aria-controls="flush-collapse-1">
              How do I place an order?
            </button>
          </h2>
          <div id="flush-collapse-1" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
            <div class="accordion-body">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Non, quod aspernatur. Inventore asperiores quaerat sint aut, repellat cum consequuntur deserunt neque possimus nesciunt, dolorem animi cumque vel necessitatibus! Accusamus ipsam iure eius repellat excepturi, ullam vitae ab facere adipisci quibusdam?</div>
          </div>
        </div>

        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-2" aria-expanded="false" aria-controls="flush-collapse-2">
              What payment methods do you accept?
            </button>
          </h2>
          <div id="flush-collapse-2" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
            <div class="accordion-body">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dignissimos soluta aspernatur quod unde assumenda nihil iste! Amet optio illo dolorum laudantium corrupti repellat laborum, numquam veritatis velit corporis, exercitationem rerum possimus, iure eos laboriosam consequuntur ad quis. Laboriosam, autem maiores.</div>
          </div>
        </div>

        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-3" aria-expanded="false" aria-controls="flush-collapse-3">
              How can I track my order?
            </button>
          </h2>
          <div id="flush-collapse-3" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
            <div class="accordion-body">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Vitae consequatur ipsa corporis quibusdam necessitatibus, aliquid excepturi iusto explicabo inventore vel mollitia fuga, quia magni qui sint dolorum at nam non quas voluptates facilis nulla officiis. A qui aspernatur nostrum facere!</div>
          </div>
        </div>

        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-4" aria-expanded="false" aria-controls="flush-collapse-4">
              What is your return policy?
            </button>
          </h2>
          <div id="flush-collapse-4" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
            <div class="accordion-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo, hic! Fuga amet numquam maxime obcaecati qui, necessitatibus excepturi iste pariatur porro quas odio non! Ducimus rem laudantium placeat, provident quae magnam iure quis voluptatem dolores blanditiis totam delectus error a?</div>
          </div>
        </div>

        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-5" aria-expanded="false" aria-controls="flush-collapse-5">
              Do you offer international shipping?
            </button>
          </h2>
          <div id="flush-collapse-5" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
            <div class="accordion-body">Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore, voluptate id. Quasi non consequuntur aliquid, aut nihil ad dicta atque doloribus eaque. Reiciendis reprehenderit hic cumque corporis. Dignissimos enim sunt repellendus! Accusamus, sed commodi recusandae nobis minima consequatur exercitationem repudiandae?</div>
          </div>
        </div>

        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-6" aria-expanded="false" aria-controls="flush-collapse-6">
              How can I contact customer support?
            </button>
          </h2>
          <div id="flush-collapse-6" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
            <div class="accordion-body">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Labore ut voluptates obcaecati tempore quae fugit cupiditate, consequatur nihil aperiam placeat, hic facere similique non explicabo incidunt amet sunt corporis dolores! Porro optio tempora, rem temporibus aut ducimus nihil animi nulla!</div>
          </div>
        </div>

      </div>

    </div>
  </section>
        </div>
      </div>
    </div>
 </section>
 <!-- THIRD SECTION - EXPLANATION POINT PART II END-->



<!-- FOURTH SECTION - EXPLANATION POINT PART III START-->
<section class="accordianExplanation" id="DetailsAccordianExplanation">
    <div class="container">

      <div class="row title-section d-flex">

      <!--LEFT IMAGE CONTENT-->
      <div class="row image-content-block d-flex">

        
        <div class="image-block">
          
          <h1>Explanation Point</h1>

          <p class="SF-16-black pb-3">If you have a damaged tooth and haven’t heard of the professional dental crowns in Sydney, then it’s your lucky day! Here at Sydney Road Dental Care, we have said goodbye to old dental crowns methods, and have instead welcomed the joys of what modern technology has to offer.</p>

          <p class="SF-16-black pb-3">Previously, patients were required to visit the clinic at least two times before their new crown was fitted and were forced to wear an uncomfortable temporary crown in the meantime. This is now a thing of the past, and we can complete the work in a single visit.</p>

          <p class="SF-16-black">Sydney Road Dental Care are dental crown experts, and not every dentist will hold that title! In fact, many other dental practices in Sydney have not yet invested in this technology, so of course you know where you’ll be heading next time you need our clinic of dental crown in Sydney!</p>



         
          <!-- <div class="d-flex align-items-center flex-column">
          <img src='assets/imgs/Service-Details/details_2.webp' alt="">
          <p class="SF-16-black">Caption For Image</p>
          </div> -->
        </div>

        <!--RIGHT CONTENT CONTAINER-->
        <div class="content-block">

          
          <h3>Made from metals, porcelain, resin and ceramics, technological advancements allow dental crowns to appear like any other healthy, natural teeth.</h3>

          <div class="d-flex image-box align-items-center flex-column">
          <img src='assets/imgs/Service-Details/details_2.webp' alt="">
          <p class="SF-16-black">Caption For Image</p>
          </div>
        </div>
        
        
          <!-- <p class="SF-16-black pb-3">If you have a damaged tooth and haven’t heard of the professional dental crowns in Sydney, then it’s your lucky day! Here at Sydney Road Dental Care, we have said goodbye to old dental crowns methods, and have instead welcomed the joys of what modern technology has to offer.</p>

          <p class="SF-16-black pb-3">Previously, patients were required to visit the clinic at least two times before their new crown was fitted and were forced to wear an uncomfortable temporary crown in the meantime. This is now a thing of the past, and we can complete the work in a single visit.</p>

          <p class="SF-16-black">Sydney Road Dental Care are dental crown experts, and not every dentist will hold that title! In fact, many other dental practices in Sydney have not yet invested in this technology, so of course you know where you’ll be heading next time you need our clinic of dental crown in Sydney!</p> -->

        </div>
      </div>


    </div>
 </div>
<!-- FOURTH SECTION - EXPLANATION POINT PART III END-->


<!-- FIFTH SECTION - CTA SECTION START-->
  <section class="faq-section" id="homeFaqSection">
    <div class="container">
      <div class="text-center mb-4">
        <h2 class="faq-title-detail mobile-faq">Explanation Point</h2>
      </div>

      <div class="accordion accordion-flush" id="accordionFlushExample">
                
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-1" aria-expanded="false" aria-controls="flush-collapse-1">
              How do I place an order?
            </button>
          </h2>
          <div id="flush-collapse-1" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
            <div class="accordion-body">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Non, quod aspernatur. Inventore asperiores quaerat sint aut, repellat cum consequuntur deserunt neque possimus nesciunt, dolorem animi cumque vel necessitatibus! Accusamus ipsam iure eius repellat excepturi, ullam vitae ab facere adipisci quibusdam?</div>
          </div>
        </div>

        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-2" aria-expanded="false" aria-controls="flush-collapse-2">
              What payment methods do you accept?
            </button>
          </h2>
          <div id="flush-collapse-2" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
            <div class="accordion-body">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dignissimos soluta aspernatur quod unde assumenda nihil iste! Amet optio illo dolorum laudantium corrupti repellat laborum, numquam veritatis velit corporis, exercitationem rerum possimus, iure eos laboriosam consequuntur ad quis. Laboriosam, autem maiores.</div>
          </div>
        </div>

        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-3" aria-expanded="false" aria-controls="flush-collapse-3">
              How can I track my order?
            </button>
          </h2>
          <div id="flush-collapse-3" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
            <div class="accordion-body">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Vitae consequatur ipsa corporis quibusdam necessitatibus, aliquid excepturi iusto explicabo inventore vel mollitia fuga, quia magni qui sint dolorum at nam non quas voluptates facilis nulla officiis. A qui aspernatur nostrum facere!</div>
          </div>
        </div>

        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-4" aria-expanded="false" aria-controls="flush-collapse-4">
              What is your return policy?
            </button>
          </h2>
          <div id="flush-collapse-4" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
            <div class="accordion-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo, hic! Fuga amet numquam maxime obcaecati qui, necessitatibus excepturi iste pariatur porro quas odio non! Ducimus rem laudantium placeat, provident quae magnam iure quis voluptatem dolores blanditiis totam delectus error a?</div>
          </div>
        </div>

        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-5" aria-expanded="false" aria-controls="flush-collapse-5">
              Do you offer international shipping?
            </button>
          </h2>
          <div id="flush-collapse-5" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
            <div class="accordion-body">Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore, voluptate id. Quasi non consequuntur aliquid, aut nihil ad dicta atque doloribus eaque. Reiciendis reprehenderit hic cumque corporis. Dignissimos enim sunt repellendus! Accusamus, sed commodi recusandae nobis minima consequatur exercitationem repudiandae?</div>
          </div>
        </div>

        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-6" aria-expanded="false" aria-controls="flush-collapse-6">
              How can I contact customer support?
            </button>
          </h2>
          <div id="flush-collapse-6" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
            <div class="accordion-body">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Labore ut voluptates obcaecati tempore quae fugit cupiditate, consequatur nihil aperiam placeat, hic facere similique non explicabo incidunt amet sunt corporis dolores! Porro optio tempora, rem temporibus aut ducimus nihil animi nulla!</div>
          </div>
        </div>

      </div>

    </div>
  </section>
<!-- FIFTH SECTION - FAQ SECTION END-->


<!-- FIFTH SECTION - ARTICLE SECTION START-->
  <section class="article-section" id="homeArticleSection">
    <div class="container">
      <div class="row justify-content-between look">
        <div class="col-md-4 title">
          <h2>Latest articles</h2>          
        </div>
        <div class="col-md-5 button d-flex flex-column align-items-end">
          <button type="button" class="btn btn-primary view-all">View All Articles</button>
        </div>
      </div>

      <div class="row blog-loop">


        <div class="blog-item d-flex">
          <div class="bi-image" style="background-image: url('assets/imgs/home/post-1.png');"></div>
          <div class="bi-content d-flex flex-column justify-content-between">
            <div class="bi-meta d-flex gap-2 justify-content-between align-items-center">
              <span class="bi-date">June 10, 2024</span>
              <span class="bi-category">Cosmetic</span>
            </div>
            <h3 class="bi-title">Why Are My Teeth Sensitive After Whitening? How to Relieve The Pain</h3>
          </div>
        </div>

        <div class="blog-item d-flex">
          <div class="bi-image" style="background-image: url('assets/imgs/home/post-2.png');"></div>
          <div class="bi-content d-flex flex-column justify-content-between">
             <div class="bi-meta d-flex gap-2 justify-content-between align-items-center">
              <span class="bi-date">June 10, 2024</span>
              <span class="bi-category">Cosmetic</span>
            </div>
            <h3 class="bi-title">Why Are My Teeth Sensitive After Whitening? How to Relieve The Pain</h3>
          </div>
        </div>


        <div class="blog-item d-flex">
          <div class="bi-image" style="background-image: url('assets/imgs/home/post-3.png');"></div>
          <div class="bi-content d-flex flex-column justify-content-between">
             <div class="bi-meta d-flex gap-2 justify-content-between align-items-center">
              <span class="bi-date">June 10, 2024</span>
              <span class="bi-category">Cosmetic</span>
            </div>
            <h3 class="bi-title">The Importance of Sunscreen for Youthful Skin</h3>
          </div>
        </div>

        <div class="blog-item d-flex">
          <div class="bi-image" style="background-image: url('assets/imgs/home/post-1.png');"></div>
          <div class="bi-content d-flex flex-column justify-content-between">
             <div class="bi-meta d-flex gap-2 justify-content-between align-items-center">
              <span class="bi-date">June 10, 2024</span>
              <span class="bi-category">Cosmetic</span>
            </div>
            <h3 class="bi-title">The Importance of Sunscreen for Youthful Skin</h3>
          </div>
        </div>

      </div>

    </div>
  </section>
<!-- FIFTH SECTION - ARTICLE SECTION END -->


<!--SIXTH SECTION - CTA STARTS-->
 <section class="cta-section py-5" id="homeCtaSection">
    <div class="container">
      <div class="row justify-content-between align-items-center" style="background-image: url('assets/imgs/home/footer-cta.png');">
        <div class="col-md-6">
          <img src="assets/imgs/home/home-icon/footer-cta-icon.svg">
          <h2>Enjoy a great experience with our service</h2>
          <p>Sydney Road Dental Care is one of the highest-rated cosmetic, implant, and general dentists in Sydney!</p>
<div class="cta-btn-group">
    <a href="#contact" class="btn fom">Find Out More</a>
    <a href="#contact" class="btn ot">Our Technology</a>
</div>
        </div>
        
      </div>
    </div>
  </section>
<!--SIXTH SECTION - CTA ENDS -->



<?php include('footer.php'); ?>